CREATE SEQUENCE seq_employee_code;
