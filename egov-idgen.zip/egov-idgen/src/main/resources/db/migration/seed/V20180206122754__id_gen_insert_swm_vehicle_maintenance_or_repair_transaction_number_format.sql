INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('swm.vehicle.maintenance.repair.transaction.number', 'default', 'MH-SWM-VMR-TRN-[SEQ_SWM_VMR_TRN_NUM]', 1);

