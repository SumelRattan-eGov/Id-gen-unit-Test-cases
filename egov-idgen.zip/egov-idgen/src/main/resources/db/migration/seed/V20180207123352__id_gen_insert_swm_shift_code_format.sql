INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('swm.shift.code', 'default', 'MH-SWM-SHIFT-CODE-[SEQ_SWM_SHIFT_CODE_NUM]', 1);

