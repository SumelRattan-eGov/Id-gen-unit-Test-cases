INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('swm.vendor.paymentdetails.paymentno', 'default', 'MH-SWM-VNDR-PMNT-[SEQ_SWM_VENDOR_PAYMENT_NUM]', 1);
