INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('swm.transaction.number', 'default', 'MH-SWM-TRN-[SEQ_SWM_TRN_NUM]', 1);
