update id_generator set format = '[cy:MM]/[fy:yyyy-yy]/[SEQ_COLL_RCPT_NUM]' where idname = 'collection.receiptno';
