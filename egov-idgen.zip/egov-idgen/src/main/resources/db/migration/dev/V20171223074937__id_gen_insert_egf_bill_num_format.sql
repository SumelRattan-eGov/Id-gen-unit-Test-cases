INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('egf.bill.default.number.format.name', 'default', 'MH-BILL-NUM-[SEQ_EGF_BILL_DFT_NUM]', 1);
