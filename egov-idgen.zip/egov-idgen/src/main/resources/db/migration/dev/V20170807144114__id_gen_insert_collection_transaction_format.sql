INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('collection.transactionno', 'default' , '[CITY.CODE][d{10}]', 4);
