INSERT INTO id_generator(idname, tenantid, format, sequencenumber) VALUES ('collection.receiptno', 'default' , 'GN-CL-[yyyy/MM/dd]-[SEQ_COLL_RCPT_NUM]', 3);
